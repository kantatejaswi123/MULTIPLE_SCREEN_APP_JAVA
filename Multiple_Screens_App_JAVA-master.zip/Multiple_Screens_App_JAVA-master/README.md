# Multiple_Screens_App_JAVA

### An Android application having multiple screens along with the reference (Button) to each screen. The code for the application is written in Java Programming Language.
